# TerminalBlock_Phoenix.pretty

Phoenix (https://www.phoenixcontact.com/) terminal block footprints.

(Most of) These footprints have been script-generated with a python script available https://github.com/pointhi/kicad-footprint-generator/scripts/TerminalBlock_Phoenix .