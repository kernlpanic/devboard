# Package_SO.pretty

This repository contains various Small Outline Integrated Circuit (SOIC, SSOP, xSOP) footprints - https://en.wikipedia.org/wiki/Small_Outline_Integrated_Circuit
