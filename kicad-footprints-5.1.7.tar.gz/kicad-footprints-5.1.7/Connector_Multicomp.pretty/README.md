# Connectors_Multicomp.pretty
This library is now deprecated. Compatible connectors can be found in Connector_IDC.pretty.
