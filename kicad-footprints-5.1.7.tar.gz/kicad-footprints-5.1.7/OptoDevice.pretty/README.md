# OptoDevice.pretty

This folder collects diverse optical devices, like:
- photo diodes
- photo transistors
- LDRs
- photo interrupters
- other optical sensors